#include<stdio.h>

void GameTitle();
void GameASK();
void GameEND();
void GameLEVEL();
void SystemIO();

void GameTitle(){
    printf("Welcom to the game of DJ vs WY\n");
    sys
}